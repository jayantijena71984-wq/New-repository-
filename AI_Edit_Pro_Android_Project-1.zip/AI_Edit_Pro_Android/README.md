# AI Edit Pro — Android APK project

This project packages the AI Edit Pro clickable prototype as a real Android app using a native WebView shell.

## Build

Open the folder in Android Studio, or push it to GitHub and run **Actions → Build AI Edit Pro APK**. The workflow uploads `app-debug.apk` as an artifact.

## Current version

- Home screen
- Video Editor prototype UI
- AI Helper prototype UI
- Local HTML/CSS/JS packaged inside the APK

This is a UI prototype wrapped as an installable Android app. Real video processing, captions, AI API calls, and licensed music integrations still need to be implemented.
